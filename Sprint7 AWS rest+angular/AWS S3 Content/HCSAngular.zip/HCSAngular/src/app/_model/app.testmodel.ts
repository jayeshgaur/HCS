export class TestModel{
    testId:any;
    testName:string;
}