export class CenterModel{
    centerId:any;
    centerName:string;
    centerContactNo:any;
    centerAddress:string;
}